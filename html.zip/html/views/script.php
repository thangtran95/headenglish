<!-- jQuery -->
<script src="resources/vendor/jquery/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="resources/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="resources/vendor/WOW-master/dist/wow.min.js"></script>
<script src="resources/vendor/slick/slick.js"></script>
<script src="resources/vendor/fancybox/jquery.fancybox.min.js"></script>
<script  type="text/javascript" src="resources/js/main.js?v=<?php echo strtotime("now"), "\n"; ?>"></script>