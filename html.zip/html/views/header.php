<header class="header">

    <div class="header-navbar">
        <nav class="navbar navbar-inverse"  role="navigation">
            <div class="container">
                <div class="navbar-collapse1" >
                    <div class="col-sm-6 col-lg-8">
                        <div class="logo">
                            <a href="index.html"><img src="resources/images/logo/logo.png"></a>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-4">
                        <div class="not-accout">
                            <ul class="login-regis">
                                <li><a href="login.html">Đăng ký</a></li>
                                <li><a href="login.html">Đăng nhập</a></li>
                            </ul>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fa fa-envelope"></i></a></li>
                            </ul>
                        </div>

                        <!-- <div class="have-account">
                            <ul class="name-user">
                                <li><h4>Nguyen Xuan Anh</h4></li>
                                <li><p>Khóa học:</p></li>
                                <li><p>Ngày hết hạn:</p></li>
                                <li><a href="#">Thông tin tài khoản</a></li>
                            </ul>
                            <ul class="avartar-user">
                                <img src="resources/images/index/avatar.png" alt="">
                            </ul>
                        </div> -->
                    </div>
                </div>
            </div>
        </nav>
    </div>

</header>