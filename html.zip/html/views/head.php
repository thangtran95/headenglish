<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>Home</title>

<!-- Bootstrap Core CSS -->
<link href="resources/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="resources/vendor/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="resources/vendor/WOW-master/css/libs/animate.css" rel="stylesheet">
<link href="resources/vendor/slick/slick.css" rel="stylesheet">
<link href="resources/vendor/slick/slick-theme.css" rel="stylesheet">
<link href="resources/fonts/utmavo/font.css" rel="stylesheet">
<link href="resources/vendor/fancybox/jquery.fancybox.min.css" rel="stylesheet">

<!-- Custom CSS -->

<link rel="stylesheet" href="resources/css/main.css?v=<?php echo strtotime("now"), "\n"; ?>" rel="stylesheet">